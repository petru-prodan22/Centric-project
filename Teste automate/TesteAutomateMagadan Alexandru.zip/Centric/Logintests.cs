﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.DevTools.V129.Animation;

namespace Centric_autotest
{
    [TestClass]
    public class Logintests
    {
       
        IWebDriver driver;

        [TestInitialize]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.trendyol.com/ro");
        }

        [TestCleanup]
        public void Cleanup() { driver.Quit(); }

        
        
        [TestMethod]
        public void TestMethod1()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Accept cookies
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));
            acceptCookiesButton.Click();

            // Identify the search bar and enter the text "tricouri"
            var searchBar = wait.Until(d => d.FindElement(By.CssSelector("input[data-testid='search-bar-input']")));
            searchBar.SendKeys("tricouri");

            // Press Enter to trigger the search
            searchBar.SendKeys(Keys.Enter);

            // Define the expected URL
            string expectedUrl = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";

            // Wait for the URL to contain the expected value
            wait.Until(d => d.Url.Contains(expectedUrl));

            // Perform the assertion
            Assert.IsTrue(driver.Url.Contains(expectedUrl), $"Expected URL to contain '{expectedUrl}', but actual URL was '{driver.Url}'");

            string expectedUrl1 = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";
            // Wait for the product element to be visible and clickable
            var product = wait.Until(d => d.FindElement(By.CssSelector(".overlaying-segment.image-overlays")));

            // Scroll the product into view (if necessary)
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", product);

            // Click on the product
            product.Click();

            var productNameElement = wait.Until(d => d.FindElement(By.CssSelector("span.product-info-product-name[data-testid='product-name']")));
            string productName = productNameElement.Text;
           

            var buttonsizepick = wait.Until(d => d.FindElement(By.XPath("//button[contains(@class, 'm') and @aria-haspopup='listbox' and @aria-expanded='false' and @aria-selected='true']")));
            buttonsizepick.Click();
            Thread.Sleep(500);

            //var sizepickL = wait.Until(d => d.FindElement(By.CssSelector("li.m[role='option'][aria-selected='true']")));
            //sizepickL.Click();
            var sizepickL = wait.Until(d => d.FindElement(By.Id("1091406444"))); //se schimba in fuctie de produsul ales;
            sizepickL.Click();

            Thread.Sleep(500);
            var buttonAdd =wait.Until(d => d.FindElement(By.Id("add-to-basket")));
            buttonAdd.Click();
            Thread.Sleep(500);

            var basketWrapper = driver.FindElement(By.CssSelector("div.basket-wrapper[data-testid='basket-wrapper']"));
            basketWrapper.Click();
            Thread.Sleep(500);

            var productNameElementInCart = wait.Until(d => d.FindElement(By.CssSelector("p.product-name[data-testid='product-name']")));
            string productNameInCart = productNameElementInCart.Text;
            
            Thread.Sleep(5000);
            Assert.AreEqual(productName, productNameInCart);
            
        }

        [TestMethod]
        public void TestMethod2()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Accept cookies
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));
            acceptCookiesButton.Click();

            // Identify the search bar and enter the text "tricouri"
            var searchBar = wait.Until(d => d.FindElement(By.CssSelector("input[data-testid='search-bar-input']")));
            searchBar.SendKeys("tricouri");

            // Press Enter to trigger the search
            searchBar.SendKeys(Keys.Enter);

            // Define the expected URL
            string expectedUrl = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";

            // Wait for the URL to contain the expected value
            wait.Until(d => d.Url.Contains(expectedUrl));

            // Perform the assertion
            Assert.IsTrue(driver.Url.Contains(expectedUrl), $"Expected URL to contain '{expectedUrl}', but actual URL was '{driver.Url}'");

            string expectedUrl1 = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";
            // Wait for the product element to be visible and clickable
            var product = wait.Until(d => d.FindElement(By.CssSelector(".overlaying-segment.image-overlays")));

            // Scroll the product into view (if necessary)
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", product);

            // Click on the product
            product.Click();

            var productNameElement = wait.Until(d => d.FindElement(By.CssSelector("span.product-info-product-name[data-testid='product-name']")));
            string productName = productNameElement.Text;

            var buttonsizepick = wait.Until(d => d.FindElement(By.XPath("//button[contains(@class, 'm') and @aria-haspopup='listbox' and @aria-expanded='false' and @aria-selected='true']")));
            buttonsizepick.Click();
            Thread.Sleep(500);

            //var sizepickL = wait.Until(d => d.FindElement(By.CssSelector("li.m[role='option'][aria-selected='true']")));
            //sizepickL.Click();
            var sizepickL = wait.Until(d => d.FindElement(By.Id("1091406444"))); //se schimba in fuctie de produsul ales;
            sizepickL.Click();

            var buttonAdd = wait.Until(d => d.FindElement(By.Id("add-to-basket")));
            
            for (int i = 0; i < 3; i++)
            {
                buttonAdd.Click();
                Thread.Sleep(5000);
            }

            var basketWrapper = driver.FindElement(By.CssSelector("div.basket-wrapper[data-testid='basket-wrapper']"));
            basketWrapper.Click();

            var productNameElementInCart = wait.Until(d => d.FindElement(By.CssSelector("p.product-name[data-testid='product-name']")));
            string productNameInCart = productNameElementInCart.Text;

            var decreaseButton = driver.FindElement(By.CssSelector("button[data-testid='quantity-decrease-button']"));
            var spanElement = decreaseButton.FindElement(By.CssSelector("span.icon-minus"));
            string spanText = spanElement.Text;

            Thread.Sleep(5000);
            Assert.AreEqual(productName, productNameInCart);
            Assert.AreEqual( "3", productNameInCart);
        }
    }
}