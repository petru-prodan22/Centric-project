﻿using OpenQA.Selenium;

namespace Centric_autotest.PageObjects
{
    public class LoginPage
    {
        private IWebDriver _driver;
        private IWebElement Email => _driver.FindElement(By.Id("login-email-input"));
        private IWebElement password => _driver.FindElement(By.Id("login-password-input"));
        private IWebElement loginButton => _driver.FindElement(By.Id("login-button"));
        private IWebElement errorMessage => _driver.FindElement(By.XPath("//h3[@data-test='error']"));

        public LoginPage(IWebDriver driver)
        {
            _driver = driver;
        }
        public void Login(string email, string password)
        {
            Email.SendKeys(email);
            this.password.SendKeys(password);
            loginButton.Click();
        }
        public string GetErrorMessage()
        {
            return errorMessage.Text;
        }
    }
}
