﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centric_autotest.PageObjects
{
    public class InventoryPage
    {IWebDriver _driver;
        private ReadOnlyCollection<IWebElement> productItems => _driver.FindElements(By.CssSelector(".inventory_item"));
        public InventoryPage(IWebDriver driver)
        { _driver = driver; }   
        public int GetProductsNumber()
        { return productItems.Count; }
    }
}
