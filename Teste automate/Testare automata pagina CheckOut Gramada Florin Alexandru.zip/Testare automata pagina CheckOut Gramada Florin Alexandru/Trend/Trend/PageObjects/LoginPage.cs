﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trend.PageObjects
{
    public class LoginPage
    {
        private IWebDriver _driver;
        private IWebElement username => _driver.FindElement(By.Id("user-name"));
        private IWebElement password => _driver.FindElement(By.Id("password"));
        private IWebElement logB => _driver.FindElement(By.Id("login-button"));
        public LoginPage(IWebDriver driver) { _driver = driver; }
        public void Login(string username, string password)
        {
            this.username.SendKeys(username);
            this.password.SendKeys(password);
            logB.Click();
        }
    }
}
