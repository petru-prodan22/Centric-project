﻿using Trend.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading;
using Trend.PageObjects;

namespace Trend
{
    [TestClass]
    public class Logintests
    {
        LoginPage loginPage;
        IWebDriver driver;
        InventoryPage inventoryPage;

        [TestInitialize]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.trendyol.com/ro");
            loginPage = new LoginPage(driver);
            inventoryPage = new InventoryPage(driver);
        }

        [TestCleanup]
        public void Cleanup() { driver.Quit(); }

        // Testul 1: Interacțiunea cu „How can I return my order?”
        [TestMethod]
        public void TestMethod1()
        {
            // Așteptăm până când butonul de acceptare a cookies apare
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));

            // Dăm click pe butonul de acceptare
            acceptCookiesButton.Click();

            // Așteptăm până când elementul care declanșează dropdown-ul devine vizibil
            var helpIcon = wait.Until(d => d.FindElement(By.CssSelector("div.help-icon svg")));

            // Pui cursorul pe elementul care declanșează dropdown-ul
            Actions actions = new Actions(driver);
            actions.MoveToElement(helpIcon).Perform();

            // Așteptăm ca dropdown-ul să devină vizibil
            var helpCenterLink = wait.Until(d => d.FindElement(By.XPath("//p[@class='name' and contains(text(), 'Help Center')]")));

            // Dăm click pe elementul "Help Center"
            helpCenterLink.Click();

            // Așteptăm până când întrebarea "How can I return my order?" devine vizibilă
            var question = wait.Until(d => d.FindElement(By.XPath("//header//p[contains(text(),'How can I return my order?')]")));

            // Dăm click pe întrebarea respectivă
            question.Click();

            // Așteptăm până când butonul cu textul "Yes" devine vizibil
            var yesButton = wait.Until(d => d.FindElement(By.XPath("//div[@class='button-content']//p[contains(text(), 'Yes')]")));

            // Dăm click pe butonul "Yes"
            yesButton.Click();

            // Poți adăuga o așteptare suplimentară pentru a observa efectul
            Thread.Sleep(1000); // Așteptare generică
        }

        // Testul 2: Apăsarea pe „Order”
        [TestMethod]
        public void TestMethod2()
        {
            // Așteptăm până când butonul de acceptare a cookies apare
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));

            // Dăm click pe butonul de acceptare
            acceptCookiesButton.Click();

            // Așteptăm până când elementul care declanșează dropdown-ul devine vizibil
            var helpIcon = wait.Until(d => d.FindElement(By.CssSelector("div.help-icon svg")));

            // Pui cursorul pe elementul care declanșează dropdown-ul
            Actions actions = new Actions(driver);
            actions.MoveToElement(helpIcon).Perform();

            // Așteptăm ca dropdown-ul să devină vizibil
            var helpCenterLink = wait.Until(d => d.FindElement(By.XPath("//p[@class='name' and contains(text(), 'Help Center')]")));

            // Dăm click pe elementul "Help Center"
            helpCenterLink.Click();

            // Așteptăm până când elementul „Order” devine vizibil
            var orderOption = wait.Until(d => d.FindElement(By.XPath("//div[@class='help-category-wrapper']//p[contains(text(), 'Order')]")));
            // Dăm click pe elementul „Order”
            orderOption.Click();

            var question = wait.Until(d => d.FindElement(By.XPath("//header//p[contains(text(),'How can I track my order?')]")));

            // Dăm click pe întrebarea respectivă
            question.Click();

            // Așteptăm până când butonul cu textul "Yes" devine vizibil
            var yesButton = wait.Until(d => d.FindElement(By.XPath("//div[@class='button-content']//p[contains(text(), 'Yes')]")));

            // Dăm click pe butonul „Yes”
            yesButton.Click();

            // Poți adăuga o așteptare suplimentară pentru a observa efectul
            Thread.Sleep(1000); // Așteptare generică
        }
        [TestMethod]
        public void TestMethod3()
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Acceptăm cookie-urile
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));
            acceptCookiesButton.Click();

            // Identificarea barei de căutare și introducerea textului "tricouri"
            var searchBar = wait.Until(d => d.FindElement(By.CssSelector("input[data-testid='search-bar-input']")));
            searchBar.SendKeys("tricouri");

            // Apăsăm tasta Enter pentru a declanșa căutarea
            searchBar.SendKeys(Keys.Enter);

            // Așteptăm ca URL-ul să se schimbe la cel așteptat
            string expectedUrl = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";
            wait.Until(d => d.Url.Contains(expectedUrl));
            Thread.Sleep(1000);
        }

    }
}