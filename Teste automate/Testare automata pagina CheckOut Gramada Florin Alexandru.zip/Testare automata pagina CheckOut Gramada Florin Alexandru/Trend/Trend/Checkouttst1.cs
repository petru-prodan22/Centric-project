﻿//using Trend.PageObject;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
//using OpenQA.Selenium.DevTools.V129.Animation;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading;
using System;
using Trend.PageObjects;

namespace Trend
{
    [TestClass]
    public class Checkouttst1
    {
        LoginPage loginPage;
        IWebDriver driver;
        InventoryPage inventoryPage;

        [TestInitialize]
        public void Setup()
        {
            ChromeOptions options= new ChromeOptions();
            options.AddArgument("--incognito");

            driver = new ChromeDriver();
            driver.Navigate().GoToUrl("https://www.trendyol.com/ro");
            loginPage = new LoginPage(driver);
            inventoryPage = new InventoryPage(driver);
        }
        [TestCleanup]
        public void Cleanup() { driver.Quit(); }

        [TestMethod]
        public void TestMethod1()
        {
            //test pentru adaugare accesare pagina chechout utilizator logat
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Accept cookies
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));
            acceptCookiesButton.Click();

            // Identify the search bar and enter the text "tricouri"
            var searchBar = wait.Until(d => d.FindElement(By.CssSelector("input[data-testid='search-bar-input']")));
            searchBar.SendKeys("tricouri");

            // Press Enter to trigger the search
            searchBar.SendKeys(Keys.Enter);

            // Define the expected URL
            string expectedUrl = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";

            // Wait for the URL to contain the expected value
            wait.Until(d => d.Url.Contains(expectedUrl));

            // Perform the assertion
            Assert.IsTrue(driver.Url.Contains(expectedUrl), $"Expected URL to contain '{expectedUrl}', but actual URL was '{driver.Url}'");

            string expectedUrl1 = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";
            // Wait for the product element to be visible and clickable
            var product = wait.Until(d => d.FindElement(By.CssSelector(".overlaying-segment.image-overlays")));

            // Scroll the product into view (if necessary)
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", product);

            // Click on the product
            product.Click();

            var buttonsizepick = wait.Until(d => d.FindElement(By.XPath("//button[contains(@class, 'm') and @aria-haspopup='listbox' and @aria-expanded='false' and @aria-selected='true']")));
            buttonsizepick.Click();
            Thread.Sleep(5000);

            //var sizepickL = wait.Until(d => d.FindElement(By.CssSelector("li.m[role='option'][aria-selected='true']")));
            //sizepickL.Click();
            var sizepickL = wait.Until(d => d.FindElement(By.Id("1091406444"))); //se schimba in fuctie de produsul ales;
            sizepickL.Click();

            var buttonAdd = wait.Until(d => d.FindElement(By.Id("add-to-basket")));
            buttonAdd.Click();
            Thread.Sleep(5000);

            var basketWrapper = driver.FindElement(By.CssSelector("div.basket-wrapper[data-testid='basket-wrapper']"));
            basketWrapper.Click();
            Thread.Sleep(5000);

            var checkoutButton = wait.Until(d => d.FindElement(By.CssSelector("button[data-testid='checkout-button']")));
            checkoutButton.Click();
            Thread.Sleep(5000);

            var loginfield = wait.Until(d => d.FindElement(By.Id("login-email-input")));
            //loginbutton.Click();
            
            loginfield.SendKeys("acc.tst010101@gmail.com");
            Thread.Sleep(1000);

            var passfield = wait.Until(d => d.FindElement(By.Id("login-password-input")));
            passfield.SendKeys("testtest1");
            Thread.Sleep(1000);

            var loginButton = wait.Until(d => d.FindElement(By.CssSelector("button[data-testid='login-button']")));
            loginButton.Click();
            Thread.Sleep(1000);


        }

        [TestMethod]
        public void TestMethod2()
        {
            // test pentru plasare comanda fara a completa toate compurile necesare

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));

            // Accept cookies
            var acceptCookiesButton = wait.Until(d => d.FindElement(By.Id("onetrust-accept-btn-handler")));
            acceptCookiesButton.Click();

            // Identify the search bar and enter the text "tricouri"
            var searchBar = wait.Until(d => d.FindElement(By.CssSelector("input[data-testid='search-bar-input']")));
            searchBar.SendKeys("tricouri");

            // Press Enter to trigger the search
            searchBar.SendKeys(Keys.Enter);

            // Define the expected URL
            string expectedUrl = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";

            // Wait for the URL to contain the expected value
            wait.Until(d => d.Url.Contains(expectedUrl));

            // Perform the assertion
            Assert.IsTrue(driver.Url.Contains(expectedUrl), $"Expected URL to contain '{expectedUrl}', but actual URL was '{driver.Url}'");

            string expectedUrl1 = "trendyol.com/en/sr?q=tricouri&qt=tricouri&st=tricouri&os=1";
            // Wait for the product element to be visible and clickable
            var product = wait.Until(d => d.FindElement(By.CssSelector(".overlaying-segment.image-overlays")));

            // Scroll the product into view (if necessary)
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", product);

            // Click on the product
            product.Click();

            var buttonsizepick = wait.Until(d => d.FindElement(By.XPath("//button[contains(@class, 'm') and @aria-haspopup='listbox' and @aria-expanded='false' and @aria-selected='true']")));
            buttonsizepick.Click();
            Thread.Sleep(5000);

            //var sizepickL = wait.Until(d => d.FindElement(By.CssSelector("li.m[role='option'][aria-selected='true']")));
            //sizepickL.Click();
            var sizepickL = wait.Until(d => d.FindElement(By.Id("1091406444"))); //se schimba in fuctie de produsul ales;
            sizepickL.Click();

            var buttonAdd = wait.Until(d => d.FindElement(By.Id("add-to-basket")));
            buttonAdd.Click();
            Thread.Sleep(5000);

            var basketWrapper = driver.FindElement(By.CssSelector("div.basket-wrapper[data-testid='basket-wrapper']"));
            basketWrapper.Click();
            Thread.Sleep(5000);

            var checkoutButton = wait.Until(d => d.FindElement(By.CssSelector("button[data-testid='checkout-button']")));
            checkoutButton.Click();
            Thread.Sleep(5000);

            var loginfield = wait.Until(d => d.FindElement(By.Id("login-email-input")));
            //loginbutton.Click();

            loginfield.SendKeys("acc.tst010101@gmail.com");
            Thread.Sleep(1000);

            var passfield = wait.Until(d => d.FindElement(By.Id("login-password-input")));
            passfield.SendKeys("testtest1");
            Thread.Sleep(1000);

            var loginButton = wait.Until(d => d.FindElement(By.CssSelector("button[data-testid='login-button']")));
            loginButton.Click();
            Thread.Sleep(1000);

            var inputfname = wait.Until(d => d.FindElement(By.Id("name")));
            inputfname.SendKeys("Relu");
            Thread.Sleep(500);

            var inputlname = wait.Until(d => d.FindElement(By.Id("surname")));
            inputlname.SendKeys("Pertofelu");
            Thread.Sleep(500);

            var saveAndContinueButton = wait.Until(d => d.FindElement(By.XPath("//button[contains(@class, 'p-button-wrapper') and contains(@class, 'p-primary') and contains(@class, 'p-large')]/p[text()='SAVE AND CONTINUE']")));
            saveAndContinueButton.Click();
        }
    }
}
